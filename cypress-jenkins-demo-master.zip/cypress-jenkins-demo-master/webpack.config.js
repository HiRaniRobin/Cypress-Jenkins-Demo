var path = require('path')

module.exports = {
    resolve: {
        alias: {
            Pages: path.resolve(__dirname, 'Pages')
        }
    }
}